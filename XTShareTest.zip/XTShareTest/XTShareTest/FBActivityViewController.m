//
//  FBActivityViewController.m
//  XTShareTest
//
//  Created by 梁新帅 on 2017/3/18.
//  Copyright © 2017年 FitBoy. All rights reserved.
//

#import "FBActivityViewController.h"

@interface FBActivityViewController ()

@end

@implementation FBActivityViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    //设置不想显示的类型
    self.excludedActivityTypes = @[UIActivityTypePostToFacebook,UIActivityTypePostToTwitter,UIActivityTypePostToVimeo,UIActivityTypePostToFlickr,UIActivityTypeAddToReadingList,UIActivityTypeAssignToContact];
    
}
/*
 <key>CFBundleDocumentTypes</key>
 <array>
 <dict>
 <key>CFBundleTypeIconFiles</key>
 <array>
 <string>FitBoy.png</string>
 </array>
 <key>LSItemContentTypes</key>
 <array>
 <string>public.content</string>
 <string>public.data</string>
 </array>
 <key>CFBundleTypeName</key>
 <string>All Files</string>
 <key>LSHandlerRank</key>
 <string>Default</string>
 </dict>
 </array>
 
 */



@end
