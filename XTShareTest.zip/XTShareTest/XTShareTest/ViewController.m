//
//  ViewController.m
//  XTShareTest
//
//  Created by 梁新帅 on 2017/3/18.
//  Copyright © 2017年 FitBoy. All rights reserved.
//

#import "ViewController.h"
#import "FBActivityViewController.h"
#import "ExActivity.h"
@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
}
-(void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event
{
    ExActivity *activity = [[ExActivity alloc]init];
    FBActivityViewController  *activityVc =[[FBActivityViewController alloc]initWithActivityItems:@[[NSURL URLWithString:@"http://www.baidu.com"]] applicationActivities:@[activity]];
    
    [self presentViewController:activityVc animated:YES completion:nil];
}




@end
