//
//  ExActivity.m
//  ShareXiTong
//
//  Created by 梁新帅 on 2017/3/17.
//  Copyright © 2017年 FitBoy. All rights reserved.
//

#import "ExActivity.h"

@implementation ExActivity
-(NSString*)activityTitle{
    //分享图标的标题
    return @"FitBoy";
}
-(UIImage*)activityImage{
    //分享上面显示的图标的 名字
    return [UIImage  imageNamed:@"FitBoy.png"];
}
//-(UIImage*)__activityImage{
// 编辑下面的图片名字显示
//    return [UIImage  imageNamed:@"FitBoy.png"];
//}
+ (UIActivityCategory)activityCategory{
    //设置在分享栏上显示  不写是在编辑栏显示
    return UIActivityCategoryShare;
}
- (BOOL)canPerformWithActivityItems:(NSArray *)activityItems
{
    //如果不实现，不会在分享栏显示图标与名字
    if(activityItems.count>0)
    {
        
    return YES;
    }
    return NO;
}


- (nullable UIViewController *)activityViewController{
    
    //点击图标弹出的viewcontrller
    UIAlertController *alert = [[UIAlertController alloc]init];
    [alert addAction:[UIAlertAction actionWithTitle:@"FitBoy" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        NSLog(@"在这里做其他逻辑处理");
    }]];
    return alert;
}

@end
