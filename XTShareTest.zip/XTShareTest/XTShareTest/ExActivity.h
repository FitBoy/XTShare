//
//  ExActivity.h
//  ShareXiTong
//
//  Created by 梁新帅 on 2017/3/17.
//  Copyright © 2017年 FitBoy. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ExActivity : UIActivity
+ (UIActivityCategory)activityCategory;
-(NSString*)activityTitle;
-(UIImage*)activityImage;
- (BOOL)canPerformWithActivityItems:(NSArray *)activityItems;   // 

- (UIViewController *)activityViewController;

@end
